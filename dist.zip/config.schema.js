"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cookieOptions = exports.configValidationSchema = void 0;
const Joi = require("@hapi/joi");
exports.configValidationSchema = Joi.object({
    PORT: Joi.number().default(3000),
    NODE_ENV: Joi.string().required(),
    DB_DATABASE_1: Joi.string().required(),
    DB_PASSWORD_1: Joi.string().required(),
    JWT_SECRET: Joi.string().required(),
    JWT_EXPIRES_IN: Joi.string().required(),
    JWT_COOKIE_EXPIRES_IN: Joi.number().default(90),
    GOOGLE_CLIENT_ID: Joi.string().required(),
    GOOGLE_SECRET: Joi.string().required(),
    MAIL_HOST: Joi.string().required(),
    MAIL_USER: Joi.string().required(),
    MAIL_PASSWORD: Joi.string().required(),
    MAIL_FROM: Joi.string().required(),
    EMAIL_PORT: Joi.number().required(),
});
exports.cookieOptions = {
    domain: 'localhost',
    secure: false,
    sameSite: 'strict',
    httpOnly: true,
    path: '/',
};
//# sourceMappingURL=config.schema.js.map