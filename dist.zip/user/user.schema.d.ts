import * as mongoose from 'mongoose';
import { UserTypeEnum } from './user.types';
import { Booking } from '../booking/booking.schema';
export declare class User {
    _id: string;
    name: string;
    email: string;
    avatar: string;
    userType: string;
    password: string;
    username: string;
    venmoUsername: string;
    identifier: string;
    description: string;
    premium: boolean;
    isOrganization: boolean;
    entertrainerFeatures: string;
    mediaUrl: string;
    location: string;
    phoneNumber: string;
    rating: number;
    booking: Booking[];
    googleId: string;
    socialAccount: boolean;
    passwordChangedAt: Date;
    passwordResetToken: string;
    passwordResetExpires: Date;
    activationToken: string;
    activationTokenExpires: Date;
    isCorrectPassword: (candidatePassword: string) => boolean;
    createPasswordResetToken: () => string;
    createActivationToken: () => string;
    changePasswordAfter: (timestamp: number) => boolean;
}
export declare type UserDocument = User & mongoose.Document;
export declare const UserSchema: mongoose.Schema<mongoose.Document<User, any, any>, mongoose.Model<mongoose.Document<User, any, any>, any, any, any>, {}, {}>;
export declare class PasswordInput {
    password: string;
}
export declare class CreateUserInput extends PasswordInput {
    username: string;
    email: string;
    userType: UserTypeEnum;
}
export declare class ActivateUserInput {
    activationToken: string;
}
export declare class LoginUserInput extends PasswordInput {
    email: string;
}
export declare class ForgotPassInput {
    email: string;
}
export declare class PassResetTokenInput extends PasswordInput {
    passwordResetToken: string;
}
export declare class UpdatePassInput extends PasswordInput {
    passwordCurrent: string;
}
export declare class GetUserByIdInput {
    _id: string;
}
export declare class UpdateUserDetailsInput {
    name: string;
    location: string;
    description: string;
    mediaUrl: string;
    phoneNumber: string;
}
export declare class SearchInput {
    query: string;
    limit?: number;
}
