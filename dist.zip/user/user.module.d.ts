export declare class UserModule {
}
