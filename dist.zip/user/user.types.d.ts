export declare enum UserTypeEnum {
    ADMIN = "admin",
    FAN = "fan",
    STAR = "star",
    VENUE = "venue"
}
