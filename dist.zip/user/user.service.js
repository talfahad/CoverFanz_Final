"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const crypto_1 = require("crypto");
const user_schema_1 = require("./user.schema");
const mail_service_1 = require("../mail/mail.service");
const user_types_1 = require("./user.types");
const user_utils_1 = require("./user.utils");
const config_1 = require("@nestjs/config");
let UserService = class UserService {
    constructor(userModel, mailService, configService) {
        this.userModel = userModel;
        this.mailService = mailService;
        this.configService = configService;
    }
    async registerUser(input) {
        const isUserExists = await this.userModel.find({
            username: input.username,
        });
        if (isUserExists.length > 0) {
            return new common_1.BadRequestException(`The username '${input.username}' is already exists. Try something new.`);
        }
        let identified = true;
        let randNum = 0;
        let identifier = '';
        while (identified) {
            randNum = Math.floor(Math.random() * 9999);
            identifier = randNum.toString();
            const isIdendifierExists = await this.userModel.find({
                identifier,
            });
            identified = isIdendifierExists.length > 0 ? identified : !identified;
        }
        const newUser = Object.assign(Object.assign({}, input), { identifier });
        const user = await this.userModel.create(newUser);
        return user;
    }
    async activateUser(input) {
        const hashedToken = crypto_1.default
            .createHash('sha256')
            .update(input.activationToken)
            .digest('hex');
        const user = await this.userModel.findOne({
            activationToken: hashedToken,
            activationTokenExpires: { $gt: new Date() },
        });
        if (!user) {
            throw new common_1.BadRequestException('Invalid or Expired Token, Signup Again!');
        }
        user.activationTokenExpires = undefined;
        user.activationToken = undefined;
        await user.save({ validateBeforeSave: false });
        await this.mailService.sendWelcome(user);
        return user;
    }
    async forgotPassword(input) {
        const { email } = input;
        const user = await this.userModel.findOne({ email: email });
        if (!user) {
            throw new common_1.NotFoundException('No active user exist with this email!');
        }
        if (user.socialAccount) {
            throw new common_1.MethodNotAllowedException('You have a social login method on this email, Please try login via that method!');
        }
        await user.save({ validateBeforeSave: false });
        return user;
    }
    async resetPassword(input) {
        const { passwordResetToken, password } = input;
        const hashedToken = crypto_1.default
            .createHash('sha256')
            .update(passwordResetToken)
            .digest('hex');
        const user = await this.userModel.findOne({
            passwordResetToken: hashedToken,
            passwordResetExpires: { $gt: new Date() },
            active: true,
        });
        if (!user) {
            throw new common_1.NotFoundException('Invalid or Expired Token!');
        }
        user.password = password;
        user.passwordResetToken = undefined;
        user.passwordResetExpires = undefined;
        await user.save({ validateBeforeSave: false });
        return user;
    }
    async updatePassword(input, id) {
        const { passwordCurrent, password } = input;
        if (passwordCurrent === password) {
            throw new common_1.BadRequestException('Both Current and New Password inputs are Same!');
        }
        const user = await this.userModel.findById(id).select('+password');
        if (!user || !(await user.isCorrectPassword(passwordCurrent))) {
            throw new common_1.UnauthorizedException('Current password is not Correct!');
        }
        user.password = password;
        await user.save({ validateBeforeSave: false });
        return user;
    }
    async updateUserDetails(input, id) {
        const user = await this.getUserById(id);
        const updatedUser = await this.userModel.findByIdAndUpdate(user._id, input, { new: true });
        return updatedUser;
    }
    async updateUserAvatar(c_user, fileName) {
        const user = await this.getUserById(c_user._id);
        user.avatar = fileName;
        await user.save({ validateBeforeSave: false });
        return user;
    }
    async getUserById(id) {
        const user = await this.userModel.findById(id).populate(user_utils_1.userPopulateOption);
        if (!user) {
            return null;
        }
        return user;
    }
    async getMyActivity(id) {
        const user = await this.getUserById(id);
        return user;
    }
    async isUserFanOrVenue(id) {
        const user = await this.getUserById(id);
        if (user.userType === user_types_1.UserTypeEnum.FAN ||
            user.userType === user_types_1.UserTypeEnum.VENUE) {
            return true;
        }
        return false;
    }
    async getUserType(id) {
        const user = await this.getUserById(id);
        switch (user.userType) {
            case user_types_1.UserTypeEnum.FAN:
                return 'fan';
            case user_types_1.UserTypeEnum.STAR:
                return 'star';
            case user_types_1.UserTypeEnum.VENUE:
                return 'venue';
        }
    }
    async getPerformerByNameOrIdentifier(query, limit = 5) {
        const newQuery = query.replace(/\s+/g, ' ').trim().replaceAll(' ', '|');
        const result = await this.userModel
            .find({
            $or: [
                { name: { $regex: new RegExp(`(${newQuery})`, 'i') } },
                { identifier: { $regex: new RegExp(`(${newQuery})`, 'i') } },
            ],
        })
            .limit(limit)
            .populate(user_utils_1.userPopulateOption);
        return result;
    }
    async getVenueByNameOrAddress(query, limit = 5) {
        const newQuery = query.replace(/\s+/g, ' ').trim().replaceAll(' ', '|');
        const result = await this.userModel
            .find({
            $or: [
                { name: { $regex: new RegExp(`(${newQuery})`, 'i') } },
                { location: { $regex: new RegExp(`(${newQuery})`, 'i') } },
            ],
        })
            .limit(limit)
            .populate(user_utils_1.userPopulateOption);
        return result;
    }
    async updateBookingForUser(userId, bookingId) {
        const user = await this.getUserById(userId);
        user.booking.push(bookingId);
        await user.save({ validateBeforeSave: false });
        return user;
    }
    async getAllUsers() {
        const users = await this.userModel.find().populate(user_utils_1.userPopulateOption);
        if (!users) {
            return null;
        }
        return users;
    }
};
UserService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(user_schema_1.User.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mail_service_1.MailService,
        config_1.ConfigService])
], UserService);
exports.UserService = UserService;
//# sourceMappingURL=user.service.js.map