"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchInput = exports.UpdateUserDetailsInput = exports.GetUserByIdInput = exports.UpdatePassInput = exports.PassResetTokenInput = exports.ForgotPassInput = exports.LoginUserInput = exports.ActivateUserInput = exports.CreateUserInput = exports.PasswordInput = exports.UserSchema = exports.User = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const graphql_1 = require("@nestjs/graphql");
const crypto_1 = require("crypto");
const class_validator_1 = require("class-validator");
const user_types_1 = require("./user.types");
const booking_schema_1 = require("../booking/booking.schema");
let User = class User {
};
__decorate([
    (0, graphql_1.Field)(() => graphql_1.ID),
    __metadata("design:type", String)
], User.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "email", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        default: 'user-default.jpg',
        validate: {
            validator: (val) => /\.(gif|jpe?g|tiff|png|webp|bmp)$/i.test(String(val.toLowerCase())),
        },
    }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "avatar", void 0);
__decorate([
    (0, mongoose_1.Prop)({ enum: user_types_1.UserTypeEnum, required: true }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "userType", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, select: false }),
    __metadata("design:type", String)
], User.prototype, "password", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, unique: true }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "username", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "venmoUsername", void 0);
__decorate([
    (0, mongoose_1.Prop)({ unique: true, required: true }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "identifier", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "description", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: true }),
    (0, graphql_1.Field)(),
    __metadata("design:type", Boolean)
], User.prototype, "premium", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: false }),
    (0, graphql_1.Field)(),
    __metadata("design:type", Boolean)
], User.prototype, "isOrganization", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "entertrainerFeatures", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "mediaUrl", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "location", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "phoneNumber", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 0 }),
    (0, graphql_1.Field)(),
    __metadata("design:type", Number)
], User.prototype, "rating", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: booking_schema_1.Booking.name }] }),
    (0, graphql_1.Field)(() => [booking_schema_1.Booking], { nullable: true }),
    __metadata("design:type", Array)
], User.prototype, "booking", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], User.prototype, "googleId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: false }),
    (0, graphql_1.Field)(),
    __metadata("design:type", Boolean)
], User.prototype, "socialAccount", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], User.prototype, "passwordChangedAt", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], User.prototype, "passwordResetToken", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], User.prototype, "passwordResetExpires", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", String)
], User.prototype, "activationToken", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    __metadata("design:type", Date)
], User.prototype, "activationTokenExpires", void 0);
User = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        toJSON: { virtuals: true },
        toObject: { virtuals: true },
    }),
    (0, graphql_1.ObjectType)()
], User);
exports.User = User;
exports.UserSchema = mongoose_1.SchemaFactory.createForClass(User);
exports.UserSchema.index({
    email: 1,
    username: 1,
    name: 1,
    identifier: 1,
    location: 1,
});
exports.UserSchema.pre('save', async function (next) {
    const user = this;
    if (!user.isModified('password')) {
        return next();
    }
    if (user.password === undefined)
        return next();
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hashSync(user.password, salt);
    user.password = hash;
    if (!user.isNew) {
        user.passwordChangedAt = new Date();
    }
    return next();
});
exports.UserSchema.methods.isCorrectPassword = async function (candidatePassword) {
    const user = this;
    return bcrypt.compare(candidatePassword, user.password).catch((e) => false);
};
exports.UserSchema.methods.createPasswordResetToken = function () {
    const user = this;
    const resetToken = crypto_1.default.randomBytes(32).toString('hex');
    user.passwordResetToken = crypto_1.default
        .createHash('sha256')
        .update(resetToken)
        .digest('hex');
    user.passwordResetExpires = new Date(Date.now() + 10 * 60 * 1000);
    return resetToken;
};
exports.UserSchema.methods.createActivationToken = function () {
    const user = this;
    const activationToken = crypto_1.default.randomBytes(32).toString('hex');
    user.activationToken = crypto_1.default
        .createHash('sha256')
        .update(activationToken)
        .digest('hex');
    user.activationTokenExpires = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);
    return activationToken;
};
exports.UserSchema.methods.changePasswordAfter = function (JWTTimestramp) {
    const user = this;
    if (user.passwordChangedAt) {
        const changedTimestramp = parseInt(String(user.passwordChangedAt.getTime() / 1000), 10);
        return JWTTimestramp < changedTimestramp;
    }
    return false;
};
let PasswordInput = class PasswordInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], PasswordInput.prototype, "password", void 0);
PasswordInput = __decorate([
    (0, graphql_1.InputType)()
], PasswordInput);
exports.PasswordInput = PasswordInput;
let CreateUserInput = class CreateUserInput extends PasswordInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], CreateUserInput.prototype, "username", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsEmail)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], CreateUserInput.prototype, "email", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], CreateUserInput.prototype, "userType", void 0);
CreateUserInput = __decorate([
    (0, graphql_1.InputType)()
], CreateUserInput);
exports.CreateUserInput = CreateUserInput;
let ActivateUserInput = class ActivateUserInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], ActivateUserInput.prototype, "activationToken", void 0);
ActivateUserInput = __decorate([
    (0, graphql_1.InputType)()
], ActivateUserInput);
exports.ActivateUserInput = ActivateUserInput;
let LoginUserInput = class LoginUserInput extends PasswordInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsEmail)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], LoginUserInput.prototype, "email", void 0);
LoginUserInput = __decorate([
    (0, graphql_1.InputType)()
], LoginUserInput);
exports.LoginUserInput = LoginUserInput;
let ForgotPassInput = class ForgotPassInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsEmail)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], ForgotPassInput.prototype, "email", void 0);
ForgotPassInput = __decorate([
    (0, graphql_1.InputType)()
], ForgotPassInput);
exports.ForgotPassInput = ForgotPassInput;
let PassResetTokenInput = class PassResetTokenInput extends PasswordInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], PassResetTokenInput.prototype, "passwordResetToken", void 0);
PassResetTokenInput = __decorate([
    (0, graphql_1.InputType)()
], PassResetTokenInput);
exports.PassResetTokenInput = PassResetTokenInput;
let UpdatePassInput = class UpdatePassInput extends PasswordInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], UpdatePassInput.prototype, "passwordCurrent", void 0);
UpdatePassInput = __decorate([
    (0, graphql_1.InputType)()
], UpdatePassInput);
exports.UpdatePassInput = UpdatePassInput;
let GetUserByIdInput = class GetUserByIdInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], GetUserByIdInput.prototype, "_id", void 0);
GetUserByIdInput = __decorate([
    (0, graphql_1.InputType)()
], GetUserByIdInput);
exports.GetUserByIdInput = GetUserByIdInput;
let UpdateUserDetailsInput = class UpdateUserDetailsInput {
};
__decorate([
    (0, graphql_1.Field)({ nullable: true }),
    __metadata("design:type", String)
], UpdateUserDetailsInput.prototype, "name", void 0);
__decorate([
    (0, graphql_1.Field)({ nullable: true }),
    __metadata("design:type", String)
], UpdateUserDetailsInput.prototype, "location", void 0);
__decorate([
    (0, graphql_1.Field)({ nullable: true }),
    __metadata("design:type", String)
], UpdateUserDetailsInput.prototype, "description", void 0);
__decorate([
    (0, graphql_1.Field)({ nullable: true }),
    __metadata("design:type", String)
], UpdateUserDetailsInput.prototype, "mediaUrl", void 0);
__decorate([
    (0, graphql_1.Field)({ nullable: true }),
    __metadata("design:type", String)
], UpdateUserDetailsInput.prototype, "phoneNumber", void 0);
UpdateUserDetailsInput = __decorate([
    (0, graphql_1.InputType)()
], UpdateUserDetailsInput);
exports.UpdateUserDetailsInput = UpdateUserDetailsInput;
let SearchInput = class SearchInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], SearchInput.prototype, "query", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, graphql_1.Field)({ nullable: true }),
    __metadata("design:type", Number)
], SearchInput.prototype, "limit", void 0);
SearchInput = __decorate([
    (0, graphql_1.InputType)()
], SearchInput);
exports.SearchInput = SearchInput;
//# sourceMappingURL=user.schema.js.map