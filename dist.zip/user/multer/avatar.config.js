"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.multerOptionsAvatar = void 0;
const path_1 = require("path");
const fs_1 = require("fs");
const multer_1 = require("multer");
const common_1 = require("@nestjs/common");
exports.multerOptionsAvatar = {
    limits: {
        fileSize: 1048576,
    },
    fileFilter: (req, file, cb) => {
        if (file.mimetype.match(/\/(jpg|jpeg|png|gif)$/)) {
            cb(null, true);
        }
        else {
            cb(new common_1.HttpException(`Unsupported file type ${(0, path_1.extname)(file.originalname)}`, common_1.HttpStatus.BAD_REQUEST), false);
        }
    },
    storage: (0, multer_1.diskStorage)({
        destination: (req, file, cb) => {
            const uploadPath = path_1.default.join(__dirname, './photos/user');
            if (!(0, fs_1.existsSync)(uploadPath)) {
                (0, fs_1.mkdirSync)(uploadPath, { recursive: true });
            }
            cb(null, uploadPath);
        },
        filename: (req, file, cb) => {
            const fileName = `user_${req.user.id.slice(-5)}_${JSON.stringify(Date.now()).slice(9, 13)}${(0, path_1.extname)(file.originalname).toLowerCase()}`;
            cb(null, fileName);
        },
    }),
};
//# sourceMappingURL=avatar.config.js.map