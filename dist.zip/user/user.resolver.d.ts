/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose" />
import { CreateUserInput, GetUserByIdInput, SearchInput, UpdatePassInput, UpdateUserDetailsInput, User } from './user.schema';
import { UserService } from './user.service';
export declare class UserResolver {
    private readonly userService;
    constructor(userService: UserService);
    registerUser(input: CreateUserInput): Promise<(User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }) | import("@nestjs/common").BadRequestException>;
    updatePassword(input: UpdatePassInput, user: User): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    updateUserDetails(input: UpdateUserDetailsInput, user: User): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    me(user: User): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    getMyActivity(user: User): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    getUserById(input: GetUserByIdInput): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    getPerformerByNameOrIdentifier(input: SearchInput): Promise<User[]>;
    getVenueByNameOrAddress(input: SearchInput): Promise<User[]>;
    allUser(): Promise<Omit<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }, never>[]>;
}
