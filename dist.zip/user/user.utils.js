"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userPopulateOption = void 0;
exports.userPopulateOption = {
    path: 'booking',
    populate: [
        {
            path: 'star_id',
            model: 'User',
        },
        {
            path: 'fan_id',
            model: 'User',
        },
        {
            path: 'venue_id',
            model: 'User',
        },
    ],
};
//# sourceMappingURL=user.utils.js.map