"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserTypeEnum = void 0;
var UserTypeEnum;
(function (UserTypeEnum) {
    UserTypeEnum["ADMIN"] = "admin";
    UserTypeEnum["FAN"] = "fan";
    UserTypeEnum["STAR"] = "star";
    UserTypeEnum["VENUE"] = "venue";
})(UserTypeEnum = exports.UserTypeEnum || (exports.UserTypeEnum = {}));
//# sourceMappingURL=user.types.js.map