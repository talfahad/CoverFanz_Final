export declare const userPopulateOption: {
    path: string;
    populate: {
        path: string;
        model: string;
    }[];
};
