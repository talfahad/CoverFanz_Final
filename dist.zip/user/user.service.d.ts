/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/schemaoptions" />
import { BadRequestException } from '@nestjs/common';
import { Model } from 'mongoose';
import { User, UserDocument, CreateUserInput, ActivateUserInput, ForgotPassInput, PassResetTokenInput, UpdatePassInput, UpdateUserDetailsInput } from './user.schema';
import { MailService } from '../mail/mail.service';
import { ConfigService } from '@nestjs/config';
export declare class UserService {
    private userModel;
    private mailService;
    private configService;
    constructor(userModel: Model<UserDocument>, mailService: MailService, configService: ConfigService);
    registerUser(input: CreateUserInput): Promise<(User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }) | BadRequestException>;
    activateUser(input: ActivateUserInput): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    forgotPassword(input: ForgotPassInput): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    resetPassword(input: PassResetTokenInput): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    updatePassword(input: UpdatePassInput, id: string): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    updateUserDetails(input: UpdateUserDetailsInput, id: string): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    updateUserAvatar(c_user: User, fileName: string): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    getUserById(id: string): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    getMyActivity(id: string): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    isUserFanOrVenue(id: string): Promise<boolean>;
    getUserType(id: string): Promise<string>;
    getPerformerByNameOrIdentifier(query: string, limit?: number): Promise<User[]>;
    getVenueByNameOrAddress(query: string, limit?: number): Promise<User[]>;
    updateBookingForUser(userId: string, bookingId: string): Promise<User>;
    getAllUsers(): Promise<Omit<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }, never>[]>;
}
