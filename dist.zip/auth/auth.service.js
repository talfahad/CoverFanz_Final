"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const user_schema_1 = require("../user/user.schema");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const jwt_1 = require("@nestjs/jwt");
const mail_service_1 = require("../mail/mail.service");
const config_schema_1 = require("../config.schema");
let AuthService = class AuthService {
    constructor(userModel, jwtService, mailService) {
        this.userModel = userModel;
        this.jwtService = jwtService;
        this.mailService = mailService;
    }
    async login(input, context) {
        const { email, password } = input;
        const socialUser = await this.userModel.findOne({
            email,
            socialAccount: true,
        });
        if (socialUser) {
            throw new common_1.ConflictException('Email is Associated With Social login Method!');
        }
        const user = await this.userModel.findOne({ email }).select('+password');
        if (!user || !(await user.isCorrectPassword(password))) {
            throw new common_1.UnauthorizedException('Invalid Username and Password');
        }
        if (user) {
            if (user.passwordResetToken) {
                user.passwordResetToken = undefined;
                user.passwordResetExpires = undefined;
                await user.save({ validateBeforeSave: false });
            }
            if (user.activationToken) {
                user.activationToken = undefined;
                user.activationTokenExpires = undefined;
                await user.save({ validateBeforeSave: false });
            }
            const token = this.jwtService.sign({
                id: user._id,
                email: user.email,
            });
            context.res.cookie('jwt', token, config_schema_1.cookieOptions);
            return user;
        }
        return null;
    }
    async logout(context) {
        context.res.cookie('jwt', '', Object.assign(Object.assign({}, config_schema_1.cookieOptions), { maxAge: 0 }));
        return null;
    }
    googleLogin(req, res) {
        const token = this.jwtService.sign({
            id: req.user._id,
            email: req.user.email,
        });
        if (req.query.state) {
            const queryParameter = JSON.parse(req.query.state);
            res.cookie('lang', queryParameter.lang, config_schema_1.cookieOptions);
        }
        res.cookie('jwt', token, config_schema_1.cookieOptions);
        res.status(200).json({
            status: 'success',
            data: {
                user: req.user,
            },
        });
    }
};
AuthService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(user_schema_1.User.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        jwt_1.JwtService,
        mail_service_1.MailService])
], AuthService);
exports.AuthService = AuthService;
//# sourceMappingURL=auth.service.js.map