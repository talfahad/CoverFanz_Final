import { ConfigService } from '@nestjs/config';
import { Strategy } from 'passport-jwt';
import { User } from 'src/user/user.schema';
import { UserService } from 'src/user/user.service';
import { Request } from 'express';
declare const JwtStrategy_base: new (...args: any[]) => Strategy;
export declare class JwtStrategy extends JwtStrategy_base {
    private readonly userService;
    private configService;
    constructor(userService: UserService, configService: ConfigService);
    validate(req: Request, validationPayload: {
        id: string;
        email: string;
        iat: number;
    }): Promise<User | null>;
}
export {};
