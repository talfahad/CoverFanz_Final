"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleStrategy = void 0;
const passport_1 = require("@nestjs/passport");
const passport_google_oauth20_1 = require("passport-google-oauth20");
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const mongoose_1 = require("mongoose");
const mongoose_2 = require("@nestjs/mongoose");
const user_schema_1 = require("../../user/user.schema");
let GoogleStrategy = class GoogleStrategy extends (0, passport_1.PassportStrategy)(passport_google_oauth20_1.Strategy, 'google') {
    constructor(userModel, configService) {
        super({
            clientID: configService.get('GOOGLE_CLIENT_ID'),
            clientSecret: configService.get('GOOGLE_SECRET'),
            callbackURL: '/auth/google/redirect',
            scope: ['email', 'profile'],
        });
        this.userModel = userModel;
        this.configService = configService;
    }
    async validate(accessToken, refreshToken, profile, done) {
        const { emails, displayName, id } = profile;
        const userEmail = emails[0].value;
        const newUser = {
            email: userEmail,
            name: displayName,
            googleId: id,
            socialAccount: true,
            password: 'nickVirus',
        };
        try {
            let user = await this.userModel.findOne({ email: userEmail });
            if (user && user.socialAccount && id === user.googleId) {
                return done(null, user);
            }
            else if (user && !user.socialAccount) {
                return done(null, false, {
                    message: 'This email is associated with (sign in with email and password) login method on this platform. If Forgot please try to reset it then login.',
                    statusCode: 409,
                });
            }
            else {
                try {
                    user = await this.userModel.create(newUser);
                    user.password = undefined;
                    await user.save({ validateBeforeSave: false });
                    user.passwordChangedAt = undefined;
                    await user.save({ validateBeforeSave: false });
                    return done(null, user);
                }
                catch (err) {
                    return done(null, false, {
                        message: 'Some Unknown Error Occured, Try Diffrent Login Method! 😒',
                        statusCode: 401,
                    });
                }
            }
        }
        catch (err) {
            return done(null, false, {
                message: 'Some Unknown Error Occured, Try Diffrent Login Method!',
                statusCode: 401,
            });
        }
    }
};
GoogleStrategy = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_2.InjectModel)(user_schema_1.User.name)),
    __metadata("design:paramtypes", [mongoose_1.Model,
        config_1.ConfigService])
], GoogleStrategy);
exports.GoogleStrategy = GoogleStrategy;
//# sourceMappingURL=google.strategy.js.map