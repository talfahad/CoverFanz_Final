/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/schemaoptions" />
import Ctx from '../types/context.type';
import { LoginUserInput, User, UserDocument } from 'src/user/user.schema';
import { Model } from 'mongoose';
import { JwtService } from '@nestjs/jwt';
import { MailService } from 'src/mail/mail.service';
export declare class AuthService {
    private userModel;
    private readonly jwtService;
    private mailService;
    constructor(userModel: Model<UserDocument>, jwtService: JwtService, mailService: MailService);
    login(input: LoginUserInput, context: Ctx): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    logout(context: Ctx): Promise<any>;
    googleLogin(req: any, res: any): void;
}
