"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Authorize = exports.AuthorizeUserType = void 0;
const common_1 = require("@nestjs/common");
const gql_auth_guard_1 = require("../guards/gql-auth.guard");
const userType_guard_1 = require("../guards/userType.guard");
const AuthorizeUserType = (userType) => (0, common_1.applyDecorators)((0, common_1.SetMetadata)('userType', [userType].flat()), (0, common_1.UseGuards)(gql_auth_guard_1.GqlAuthGuard, userType_guard_1.UserTypeGuard));
exports.AuthorizeUserType = AuthorizeUserType;
const Authorize = (userType) => (0, common_1.applyDecorators)((0, common_1.SetMetadata)('userType', [userType].flat()), (0, common_1.UseGuards)(gql_auth_guard_1.GqlAuthGuard, userType_guard_1.UserTypeGuard));
exports.Authorize = Authorize;
//# sourceMappingURL=authorize.decorator.js.map