/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose" />
import Ctx from 'src/types/context.type';
import { User, LoginUserInput } from 'src/user/user.schema';
import { AuthService } from './auth.service';
export declare class AuthResolver {
    private readonly authService;
    constructor(authService: AuthService);
    login(input: LoginUserInput, context: Ctx): Promise<User & import("mongoose").Document<any, any, any> & {
        _id: any;
    }>;
    logout(context: Ctx): Promise<any>;
}
