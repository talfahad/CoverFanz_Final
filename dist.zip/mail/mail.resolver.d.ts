import { MailService } from './mail.service';
export declare class MailResolver {
    private readonly mailService;
    constructor(mailService: MailService);
}
