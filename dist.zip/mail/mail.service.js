"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailService = void 0;
const mailer_1 = require("@nestjs-modules/mailer");
const common_1 = require("@nestjs/common");
const common_2 = require("@nestjs/common");
let MailService = class MailService {
    constructor(mailerService) {
        this.mailerService = mailerService;
        this.logger = new common_2.Logger('MailService');
        this.contextObj = {
            companyName: 'CoverFanz',
            siteContactNum: '+13XXXXXXXXXXX',
            siteContactEmail: 'example@gmail.com',
            siteContactTime: 'Monday-Friday, 8.00AM - 6.00PM EST',
            siteURL: 'https://www.coverfanz.com',
            siteLogoURL: 'https://i.ibb.co/VYyZqRr/webanion-main-logo-color-black.png',
            facebookProfileId: 'coverfanz',
            twitterProfileId: 'coverfanz',
            instagramProfileId: 'coverfanz',
            youtubeChannelId: '',
            yearNow: new Date().getFullYear(),
            unsubscribeCallbackURL: 'https://www.coverfanz.com/unsubscribe',
            companyLocation: 'Address is here',
        };
    }
    async sendUserConfirmation(user, token) {
        const url = `http://localhost:3000/auth/activateUser?token=${token}`;
        try {
            await this.mailerService.sendMail({
                to: user.email,
                subject: 'Confirm your Email',
                template: './confirmationEmail',
                context: Object.assign({ userName: user.name, userEmail: user.email, url }, this.contextObj),
            });
        }
        catch (err) {
            this.logger.error(err);
            throw new common_1.BadGatewayException('Error Confirmation Email Sending.');
        }
    }
    async sendPasswordResetToken(user, token) {
        const url = `http://localhost:3000/auth/passwordReset?token=${token}`;
        try {
            await this.mailerService.sendMail({
                to: user.email,
                subject: 'Reset your Password',
                template: './forgotPassword',
                context: Object.assign({ userName: user.name, userEmail: user.email, url }, this.contextObj),
            });
        }
        catch (err) {
            this.logger.error(err);
            throw new common_1.BadGatewayException('Error Reset Email Sending.');
        }
    }
    async sendPasswordResetSuccess(user) {
        const url = `http://localhost:3000/`;
        try {
            await this.mailerService.sendMail({
                to: user.email,
                subject: 'Password Reset Success',
                template: './resetSuccess',
                context: Object.assign({ userName: user.name, userEmail: user.email, url }, this.contextObj),
            });
        }
        catch (err) {
            this.logger.error(err);
        }
    }
    async sendWelcome(user) {
        const url = `http://localhost:3000/`;
        try {
            await this.mailerService.sendMail({
                to: user.email,
                subject: 'Account Activation Success',
                template: './welcome',
                context: Object.assign({ userName: user.name, userEmail: user.email, url }, this.contextObj),
            });
        }
        catch (err) {
            this.logger.error(err);
        }
    }
    async sendPasswordChangedSuccess(user) {
        const url = `http://localhost:4000/`;
        try {
            await this.mailerService.sendMail({
                to: user.email,
                subject: 'Password Changed Success',
                template: './passwordChanged',
                context: Object.assign({ userName: user.name, userEmail: user.email, url }, this.contextObj),
            });
        }
        catch (err) {
            this.logger.error(err);
        }
    }
};
MailService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [mailer_1.MailerService])
], MailService);
exports.MailService = MailService;
//# sourceMappingURL=mail.service.js.map