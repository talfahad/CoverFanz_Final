import { Request, Response } from 'express';
declare type Ctx = {
    req: Request;
    res: Response;
};
export default Ctx;
