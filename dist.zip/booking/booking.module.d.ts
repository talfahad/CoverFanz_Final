export declare class BookingModule {
}
