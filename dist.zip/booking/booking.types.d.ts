export declare enum BookingTypeEnum {
    PENDING = "pending",
    ACCEPTED = "accepted",
    REJECTED = "rejected"
}
