"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookingTypeEnum = void 0;
var BookingTypeEnum;
(function (BookingTypeEnum) {
    BookingTypeEnum["PENDING"] = "pending";
    BookingTypeEnum["ACCEPTED"] = "accepted";
    BookingTypeEnum["REJECTED"] = "rejected";
})(BookingTypeEnum = exports.BookingTypeEnum || (exports.BookingTypeEnum = {}));
//# sourceMappingURL=booking.types.js.map