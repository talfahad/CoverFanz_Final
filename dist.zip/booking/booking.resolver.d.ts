/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/schemaoptions" />
/// <reference types="mongoose" />
import { User } from 'src/user/user.schema';
import { Booking, BookingInput, UpdateBookingStatusInput } from './booking.schema';
import { BookingService } from './booking.service';
export declare class BookingResolver {
    private readonly bookingService;
    constructor(bookingService: BookingService);
    createBooking(input: BookingInput, user: User): Promise<import("@nestjs/common").HttpException | (Booking & import("mongoose").Document<any, any, any> & {
        _id: any;
    })>;
    updateBookingStatusById(input: UpdateBookingStatusInput, user: User): Promise<import("@nestjs/common").BadRequestException | (Booking & import("mongoose").Document<any, any, any> & {
        _id: any;
    })>;
}
