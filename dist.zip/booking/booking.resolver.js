"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookingResolver = void 0;
const graphql_1 = require("@nestjs/graphql");
const user_schema_1 = require("../user/user.schema");
const booking_schema_1 = require("./booking.schema");
const booking_service_1 = require("./booking.service");
const currentUser_decorator_1 = require("../auth/decorator/currentUser.decorator");
const common_1 = require("@nestjs/common");
const gql_auth_guard_1 = require("../auth/guards/gql-auth.guard");
let BookingResolver = class BookingResolver {
    constructor(bookingService) {
        this.bookingService = bookingService;
    }
    async createBooking(input, user) {
        return this.bookingService.createBooking(input, user._id);
    }
    async updateBookingStatusById(input, user) {
        return this.bookingService.updateBookingStatusById(input, user._id);
    }
};
__decorate([
    (0, common_1.UseGuards)(gql_auth_guard_1.GqlAuthGuard),
    (0, graphql_1.Mutation)(() => booking_schema_1.Booking),
    __param(0, (0, graphql_1.Args)('input')),
    __param(1, (0, currentUser_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [booking_schema_1.BookingInput,
        user_schema_1.User]),
    __metadata("design:returntype", Promise)
], BookingResolver.prototype, "createBooking", null);
__decorate([
    (0, common_1.UseGuards)(gql_auth_guard_1.GqlAuthGuard),
    (0, graphql_1.Mutation)(() => booking_schema_1.Booking),
    __param(0, (0, graphql_1.Args)('input')),
    __param(1, (0, currentUser_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [booking_schema_1.UpdateBookingStatusInput,
        user_schema_1.User]),
    __metadata("design:returntype", Promise)
], BookingResolver.prototype, "updateBookingStatusById", null);
BookingResolver = __decorate([
    (0, graphql_1.Resolver)('Booking'),
    __metadata("design:paramtypes", [booking_service_1.BookingService])
], BookingResolver);
exports.BookingResolver = BookingResolver;
//# sourceMappingURL=booking.resolver.js.map