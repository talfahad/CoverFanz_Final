/// <reference types="mongoose/types/pipelinestage" />
/// <reference types="mongoose/types/connection" />
/// <reference types="mongoose/types/cursor" />
/// <reference types="mongoose/types/document" />
/// <reference types="mongoose/types/error" />
/// <reference types="mongoose/types/mongooseoptions" />
/// <reference types="mongoose/types/schemaoptions" />
import { BadRequestException, HttpException } from '@nestjs/common';
import { Booking, BookingDocument, BookingInput, UpdateBookingStatusInput } from './booking.schema';
import { Model } from 'mongoose';
import { UserService } from 'src/user/user.service';
export declare class BookingService {
    private bookingModel;
    private userService;
    constructor(bookingModel: Model<BookingDocument>, userService: UserService);
    createBooking(input: BookingInput, id: string): Promise<HttpException | (Booking & import("mongoose").Document<any, any, any> & {
        _id: any;
    })>;
    updateBookingStatusById(input: UpdateBookingStatusInput, id: string): Promise<BadRequestException | (Booking & import("mongoose").Document<any, any, any> & {
        _id: any;
    })>;
}
