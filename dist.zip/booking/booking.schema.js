"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateBookingStatusInput = exports.BookingInput = exports.BookingSchema = exports.Booking = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose = require("mongoose");
const graphql_1 = require("@nestjs/graphql");
const class_validator_1 = require("class-validator");
const user_schema_1 = require("../user/user.schema");
const booking_types_1 = require("./booking.types");
let Booking = class Booking {
};
__decorate([
    (0, graphql_1.Field)(() => graphql_1.ID),
    __metadata("design:type", String)
], Booking.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], Booking.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], Booking.prototype, "typeOfWork", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: '' }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], Booking.prototype, "terms", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", Date)
], Booking.prototype, "date", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", Number)
], Booking.prototype, "payment", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], Booking.prototype, "startTime", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], Booking.prototype, "endTime", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", Number)
], Booking.prototype, "hoursWorked", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], Booking.prototype, "address", void 0);
__decorate([
    (0, mongoose_1.Prop)(),
    (0, graphql_1.Field)({ nullable: true }),
    __metadata("design:type", Boolean)
], Booking.prototype, "accepted", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: booking_types_1.BookingTypeEnum.PENDING }),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], Booking.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: mongoose.Schema.Types.ObjectId,
        ref: 'user',
        required: true,
    }),
    (0, graphql_1.Field)(() => user_schema_1.User),
    __metadata("design:type", user_schema_1.User)
], Booking.prototype, "star_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: mongoose.Schema.Types.ObjectId, ref: 'user' }),
    (0, graphql_1.Field)(() => user_schema_1.User, { nullable: true }),
    __metadata("design:type", user_schema_1.User)
], Booking.prototype, "fan_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: mongoose.Schema.Types.ObjectId, ref: 'user' }),
    (0, graphql_1.Field)(() => user_schema_1.User, { nullable: true }),
    __metadata("design:type", user_schema_1.User)
], Booking.prototype, "venue_id", void 0);
Booking = __decorate([
    (0, mongoose_1.Schema)({
        timestamps: true,
        toJSON: { virtuals: true },
        toObject: { virtuals: true },
    }),
    (0, graphql_1.ObjectType)()
], Booking);
exports.Booking = Booking;
exports.BookingSchema = mongoose_1.SchemaFactory.createForClass(Booking);
exports.BookingSchema.index({ email: 1, date: 1, accepted: 1, status: 1, star_id: 1 });
let BookingInput = class BookingInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "title", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "address", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "typeOfWork", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "date", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "startTime", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "endTime", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "terms", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", Number)
], BookingInput.prototype, "payment", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], BookingInput.prototype, "star_id", void 0);
BookingInput = __decorate([
    (0, graphql_1.InputType)()
], BookingInput);
exports.BookingInput = BookingInput;
let UpdateBookingStatusInput = class UpdateBookingStatusInput {
};
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", String)
], UpdateBookingStatusInput.prototype, "booking_id", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsBoolean)(),
    (0, graphql_1.Field)(),
    __metadata("design:type", Boolean)
], UpdateBookingStatusInput.prototype, "accepted", void 0);
UpdateBookingStatusInput = __decorate([
    (0, graphql_1.InputType)()
], UpdateBookingStatusInput);
exports.UpdateBookingStatusInput = UpdateBookingStatusInput;
//# sourceMappingURL=booking.schema.js.map