import * as mongoose from 'mongoose';
import { User } from '../user/user.schema';
import { BookingTypeEnum } from './booking.types';
export declare class Booking {
    _id: string;
    title: string;
    typeOfWork: string;
    terms: string;
    date: Date;
    payment: number;
    startTime: string;
    endTime: string;
    hoursWorked: number;
    address: string;
    accepted: boolean;
    status: BookingTypeEnum;
    star_id: User;
    fan_id: User;
    venue_id: User;
}
export declare type BookingDocument = Booking & mongoose.Document;
export declare const BookingSchema: mongoose.Schema<mongoose.Document<Booking, any, any>, mongoose.Model<mongoose.Document<Booking, any, any>, any, any, any>, {}, {}>;
export declare class BookingInput {
    title: string;
    address: string;
    typeOfWork: string;
    date: string;
    startTime: string;
    endTime: string;
    terms: string;
    payment: number;
    star_id: string;
}
export declare class UpdateBookingStatusInput {
    booking_id: string;
    accepted: boolean;
}
