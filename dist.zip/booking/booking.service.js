"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookingService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const booking_schema_1 = require("./booking.schema");
const mongoose_2 = require("mongoose");
const user_service_1 = require("../user/user.service");
const user_types_1 = require("../user/user.types");
const booking_types_1 = require("./booking.types");
let BookingService = class BookingService {
    constructor(bookingModel, userService) {
        this.bookingModel = bookingModel;
        this.userService = userService;
    }
    async createBooking(input, id) {
        const sender = await this.userService.getUserById(id);
        const receiver = await this.userService.getUserById(input.star_id);
        if (!sender.premium || !receiver.premium) {
            return new common_1.HttpException('Only Subscribed fan or venue can send or receive request.', common_1.HttpStatus.PAYMENT_REQUIRED);
        }
        if (sender.userType === user_types_1.UserTypeEnum.STAR)
            return new common_1.BadRequestException('Only Fan or Venue can Book Star');
        let newUser;
        if (sender.userType === 'fan') {
            newUser = Object.assign(Object.assign({}, input), { fan_id: id });
        }
        if (sender.userType === 'venue') {
            newUser = Object.assign(Object.assign({}, input), { venue_id: id });
        }
        const booking = await this.bookingModel.create(newUser);
        await this.userService.updateBookingForUser(booking.star_id, booking._id);
        if (booking.fan_id) {
            await this.userService.updateBookingForUser(booking.fan_id, booking._id);
        }
        if (booking.venue_id) {
            await this.userService.updateBookingForUser(booking.venue_id, booking._id);
        }
        return booking;
    }
    async updateBookingStatusById(input, id) {
        const { booking_id, accepted } = input;
        const booking = await this.bookingModel.findById(booking_id);
        const user = await this.userService.getUserById(id);
        if (user.userType !== user_types_1.UserTypeEnum.STAR ||
            !user._id.equals(booking.star_id)) {
            return new common_1.BadRequestException('Only requested star can Take the decission of updating status.');
        }
        if (accepted) {
            booking.accepted = accepted;
            booking.status = booking_types_1.BookingTypeEnum.ACCEPTED;
        }
        else {
            booking.accepted = false;
            booking.status = booking_types_1.BookingTypeEnum.REJECTED;
        }
        await booking.save({ validateBeforeSave: false });
        return booking;
    }
};
BookingService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(booking_schema_1.Booking.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        user_service_1.UserService])
], BookingService);
exports.BookingService = BookingService;
//# sourceMappingURL=booking.service.js.map